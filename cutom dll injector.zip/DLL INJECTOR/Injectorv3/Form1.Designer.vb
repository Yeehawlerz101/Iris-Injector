﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.CarbonFiberTheme1 = New Injectorv3.CarbonFiberTheme()
        Me.CarbonFiberLabel2 = New Injectorv3.CarbonFiberLabel()
        Me.CarbonFiberCheckbox1 = New Injectorv3.CarbonFiberCheckbox()
        Me.CarbonFiberLabel1 = New Injectorv3.CarbonFiberLabel()
        Me.CarbonFiberTextBox1 = New Injectorv3.CarbonFiberTextBox()
        Me.DLLs = New Injectorv3.CarbonFiberListBox()
        Me.CarbonFiberButton5 = New Injectorv3.CarbonFiberButton()
        Me.CarbonFiberButton4 = New Injectorv3.CarbonFiberButton()
        Me.CarbonFiberButton3 = New Injectorv3.CarbonFiberButton()
        Me.CarbonFiberButton2 = New Injectorv3.CarbonFiberButton()
        Me.CarbonFiberButton1 = New Injectorv3.CarbonFiberButton()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.CarbonFiberTheme1.SuspendLayout()
        Me.SuspendLayout()
        '
        'CarbonFiberTheme1
        '
        Me.CarbonFiberTheme1.BackColor = System.Drawing.Color.FromArgb(CType(CType(22, Byte), Integer), CType(CType(22, Byte), Integer), CType(CType(22, Byte), Integer))
        Me.CarbonFiberTheme1.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.CarbonFiberTheme1.Colors = New Injectorv3.Bloom(-1) {}
        Me.CarbonFiberTheme1.Controls.Add(Me.CarbonFiberLabel2)
        Me.CarbonFiberTheme1.Controls.Add(Me.CarbonFiberCheckbox1)
        Me.CarbonFiberTheme1.Controls.Add(Me.CarbonFiberLabel1)
        Me.CarbonFiberTheme1.Controls.Add(Me.CarbonFiberTextBox1)
        Me.CarbonFiberTheme1.Controls.Add(Me.DLLs)
        Me.CarbonFiberTheme1.Controls.Add(Me.CarbonFiberButton5)
        Me.CarbonFiberTheme1.Controls.Add(Me.CarbonFiberButton4)
        Me.CarbonFiberTheme1.Controls.Add(Me.CarbonFiberButton3)
        Me.CarbonFiberTheme1.Controls.Add(Me.CarbonFiberButton2)
        Me.CarbonFiberTheme1.Controls.Add(Me.CarbonFiberButton1)
        Me.CarbonFiberTheme1.Customization = ""
        Me.CarbonFiberTheme1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.CarbonFiberTheme1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.CarbonFiberTheme1.Icon = Nothing
        Me.CarbonFiberTheme1.Image = Nothing
        Me.CarbonFiberTheme1.Location = New System.Drawing.Point(0, 0)
        Me.CarbonFiberTheme1.Movable = True
        Me.CarbonFiberTheme1.Name = "CarbonFiberTheme1"
        Me.CarbonFiberTheme1.NoRounding = False
        Me.CarbonFiberTheme1.ShowIcon = False
        Me.CarbonFiberTheme1.Sizable = False
        Me.CarbonFiberTheme1.Size = New System.Drawing.Size(395, 347)
        Me.CarbonFiberTheme1.SmartBounds = True
        Me.CarbonFiberTheme1.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultLocation
        Me.CarbonFiberTheme1.TabIndex = 0
        Me.CarbonFiberTheme1.Text = "DLL Injector by LaMe1337"
        Me.CarbonFiberTheme1.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.CarbonFiberTheme1.Transparent = False
        '
        'CarbonFiberLabel2
        '
        Me.CarbonFiberLabel2.BackColor = System.Drawing.Color.Transparent
        Me.CarbonFiberLabel2.Colors = New Injectorv3.Bloom(-1) {}
        Me.CarbonFiberLabel2.Customization = ""
        Me.CarbonFiberLabel2.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.CarbonFiberLabel2.Image = Nothing
        Me.CarbonFiberLabel2.Location = New System.Drawing.Point(18, 99)
        Me.CarbonFiberLabel2.Name = "CarbonFiberLabel2"
        Me.CarbonFiberLabel2.NoRounding = False
        Me.CarbonFiberLabel2.Size = New System.Drawing.Size(55, 14)
        Me.CarbonFiberLabel2.TabIndex = 11
        Me.CarbonFiberLabel2.Text = "Process:"
        Me.CarbonFiberLabel2.Transparent = True
        '
        'CarbonFiberCheckbox1
        '
        Me.CarbonFiberCheckbox1.Checked = False
        Me.CarbonFiberCheckbox1.Colors = New Injectorv3.Bloom(-1) {}
        Me.CarbonFiberCheckbox1.Customization = ""
        Me.CarbonFiberCheckbox1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.CarbonFiberCheckbox1.Image = Nothing
        Me.CarbonFiberCheckbox1.Location = New System.Drawing.Point(24, 314)
        Me.CarbonFiberCheckbox1.MaximumSize = New System.Drawing.Size(600, 16)
        Me.CarbonFiberCheckbox1.MinimumSize = New System.Drawing.Size(50, 16)
        Me.CarbonFiberCheckbox1.Name = "CarbonFiberCheckbox1"
        Me.CarbonFiberCheckbox1.NoRounding = False
        Me.CarbonFiberCheckbox1.Size = New System.Drawing.Size(136, 16)
        Me.CarbonFiberCheckbox1.TabIndex = 10
        Me.CarbonFiberCheckbox1.Text = "Close after Injection"
        Me.CarbonFiberCheckbox1.Transparent = False
        '
        'CarbonFiberLabel1
        '
        Me.CarbonFiberLabel1.BackColor = System.Drawing.Color.Transparent
        Me.CarbonFiberLabel1.Colors = New Injectorv3.Bloom(-1) {}
        Me.CarbonFiberLabel1.Customization = ""
        Me.CarbonFiberLabel1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.CarbonFiberLabel1.Image = Nothing
        Me.CarbonFiberLabel1.Location = New System.Drawing.Point(18, 54)
        Me.CarbonFiberLabel1.Name = "CarbonFiberLabel1"
        Me.CarbonFiberLabel1.NoRounding = False
        Me.CarbonFiberLabel1.Size = New System.Drawing.Size(50, 14)
        Me.CarbonFiberLabel1.TabIndex = 7
        Me.CarbonFiberLabel1.Text = "Waiting"
        Me.CarbonFiberLabel1.Transparent = True
        '
        'CarbonFiberTextBox1
        '
        Me.CarbonFiberTextBox1.Colors = New Injectorv3.Bloom(-1) {}
        Me.CarbonFiberTextBox1.Customization = ""
        Me.CarbonFiberTextBox1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.CarbonFiberTextBox1.Image = Nothing
        Me.CarbonFiberTextBox1.Location = New System.Drawing.Point(74, 93)
        Me.CarbonFiberTextBox1.MaxLength = 32767
        Me.CarbonFiberTextBox1.Multiline = False
        Me.CarbonFiberTextBox1.Name = "CarbonFiberTextBox1"
        Me.CarbonFiberTextBox1.NoRounding = False
        Me.CarbonFiberTextBox1.ReadOnly = False
        Me.CarbonFiberTextBox1.Size = New System.Drawing.Size(86, 24)
        Me.CarbonFiberTextBox1.TabIndex = 6
        Me.CarbonFiberTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.CarbonFiberTextBox1.Transparent = False
        Me.CarbonFiberTextBox1.UseSystemPasswordChar = False
        '
        'DLLs
        '
        Me.DLLs.BackColor = System.Drawing.Color.FromArgb(CType(CType(22, Byte), Integer), CType(CType(22, Byte), Integer), CType(CType(22, Byte), Integer))
        Me.DLLs.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.DLLs.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.DLLs.FormattingEnabled = True
        Me.DLLs.ItemHeight = 15
        Me.DLLs.Location = New System.Drawing.Point(24, 123)
        Me.DLLs.Name = "DLLs"
        Me.DLLs.Size = New System.Drawing.Size(136, 90)
        Me.DLLs.TabIndex = 5
        '
        'CarbonFiberButton5
        '
        Me.CarbonFiberButton5.Colors = New Injectorv3.Bloom(-1) {}
        Me.CarbonFiberButton5.Customization = ""
        Me.CarbonFiberButton5.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.CarbonFiberButton5.Image = Nothing
        Me.CarbonFiberButton5.Location = New System.Drawing.Point(18, 226)
        Me.CarbonFiberButton5.Name = "CarbonFiberButton5"
        Me.CarbonFiberButton5.NoRounding = False
        Me.CarbonFiberButton5.Size = New System.Drawing.Size(142, 72)
        Me.CarbonFiberButton5.TabIndex = 4
        Me.CarbonFiberButton5.Text = "Close"
        Me.CarbonFiberButton5.Transparent = False
        '
        'CarbonFiberButton4
        '
        Me.CarbonFiberButton4.Colors = New Injectorv3.Bloom(-1) {}
        Me.CarbonFiberButton4.Customization = ""
        Me.CarbonFiberButton4.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.CarbonFiberButton4.Image = Nothing
        Me.CarbonFiberButton4.Location = New System.Drawing.Point(231, 226)
        Me.CarbonFiberButton4.Name = "CarbonFiberButton4"
        Me.CarbonFiberButton4.NoRounding = False
        Me.CarbonFiberButton4.Size = New System.Drawing.Size(142, 72)
        Me.CarbonFiberButton4.TabIndex = 3
        Me.CarbonFiberButton4.Text = "Inject"
        Me.CarbonFiberButton4.Transparent = False
        '
        'CarbonFiberButton3
        '
        Me.CarbonFiberButton3.Colors = New Injectorv3.Bloom(-1) {}
        Me.CarbonFiberButton3.Customization = ""
        Me.CarbonFiberButton3.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.CarbonFiberButton3.Image = Nothing
        Me.CarbonFiberButton3.Location = New System.Drawing.Point(231, 161)
        Me.CarbonFiberButton3.Name = "CarbonFiberButton3"
        Me.CarbonFiberButton3.NoRounding = False
        Me.CarbonFiberButton3.Size = New System.Drawing.Size(142, 59)
        Me.CarbonFiberButton3.TabIndex = 2
        Me.CarbonFiberButton3.Text = "Remove list"
        Me.CarbonFiberButton3.Transparent = False
        '
        'CarbonFiberButton2
        '
        Me.CarbonFiberButton2.Colors = New Injectorv3.Bloom(-1) {}
        Me.CarbonFiberButton2.Customization = ""
        Me.CarbonFiberButton2.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.CarbonFiberButton2.Image = Nothing
        Me.CarbonFiberButton2.Location = New System.Drawing.Point(231, 99)
        Me.CarbonFiberButton2.Name = "CarbonFiberButton2"
        Me.CarbonFiberButton2.NoRounding = False
        Me.CarbonFiberButton2.Size = New System.Drawing.Size(142, 56)
        Me.CarbonFiberButton2.TabIndex = 1
        Me.CarbonFiberButton2.Text = "Remove"
        Me.CarbonFiberButton2.Transparent = False
        '
        'CarbonFiberButton1
        '
        Me.CarbonFiberButton1.Colors = New Injectorv3.Bloom(-1) {}
        Me.CarbonFiberButton1.Customization = ""
        Me.CarbonFiberButton1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.CarbonFiberButton1.Image = Nothing
        Me.CarbonFiberButton1.Location = New System.Drawing.Point(231, 38)
        Me.CarbonFiberButton1.Name = "CarbonFiberButton1"
        Me.CarbonFiberButton1.NoRounding = False
        Me.CarbonFiberButton1.Size = New System.Drawing.Size(142, 55)
        Me.CarbonFiberButton1.TabIndex = 0
        Me.CarbonFiberButton1.Text = "Browse"
        Me.CarbonFiberButton1.Transparent = False
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "Select a DLL"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(395, 347)
        Me.Controls.Add(Me.CarbonFiberTheme1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.ShowIcon = False
        Me.Text = "DLL Injector by LaMe1337"
        Me.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.CarbonFiberTheme1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents CarbonFiberTheme1 As CarbonFiberTheme
    Friend WithEvents CarbonFiberButton5 As CarbonFiberButton
    Friend WithEvents CarbonFiberButton4 As CarbonFiberButton
    Friend WithEvents CarbonFiberButton3 As CarbonFiberButton
    Friend WithEvents CarbonFiberButton2 As CarbonFiberButton
    Friend WithEvents CarbonFiberButton1 As CarbonFiberButton
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents CarbonFiberTextBox1 As CarbonFiberTextBox
    Friend WithEvents DLLs As CarbonFiberListBox
    Friend WithEvents CarbonFiberLabel1 As CarbonFiberLabel
    Friend WithEvents CarbonFiberCheckbox1 As CarbonFiberCheckbox
    Friend WithEvents CarbonFiberLabel2 As CarbonFiberLabel
End Class
